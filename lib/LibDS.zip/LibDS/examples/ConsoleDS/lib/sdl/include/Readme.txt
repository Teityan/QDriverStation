SDL
===

These are the include files for the SDL library, which we use in order to get access to the joysticks connected to the user's computer.
