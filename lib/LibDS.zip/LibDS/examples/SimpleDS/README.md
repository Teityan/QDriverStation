# SimpleDS

A simple GUI DS implementation with Qt/C++. Joystick input is emulated with the keyboard.

### Dependencies

The only dependency for this project is Qt itself, the project should compile with either Qt4 or Qt5.

### License

This project is released under the MIT license.
